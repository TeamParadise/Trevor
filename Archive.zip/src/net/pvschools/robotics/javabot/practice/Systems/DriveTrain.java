/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package net.pvschools.robotics.javabot.practice.Systems;

import edu.wpi.first.wpilibj.RobotDrive;
import edu.wpi.first.wpilibj.command.PIDSubsystem;
import net.pvschools.robotics.javabot.practice.Map;


public class DriveTrain extends PIDSubsystem {
    private static final double Kp = 3;
    private static final double Ki = .2;
    private static final double Kd = 0.0;
    
    RobotDrive drive;

    public DriveTrain() {
        super("DriveTrain", Kp, Ki, Kd);
        drive = new RobotDrive(Map.leftMotor, Map.rightMotor);
    }
    
    public void initDefaultCommand() {
        
    }
    
    protected void usePIDOutput(double output) {
        
    }

    protected double returnPIDInput() {
        return 0D;
    }
    
    public void driveCartesian(double x, double y, double twist, double gyroAngle) {
        drive.mecanumDrive_Cartesian(x, y, twist, gyroAngle);
    }    
    
}
