/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package net.pvschools.robotics.javabot.practice;

/**
 *
 * @author student
 */
public class Map {
    /**Motor Ports*/
   public static final int
            leftMotor = 1,
            rightMotor = 2,
           joystickPort = 3;
}
